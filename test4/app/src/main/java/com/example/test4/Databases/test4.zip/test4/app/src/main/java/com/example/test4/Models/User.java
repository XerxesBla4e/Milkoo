package com.example.test4.Models;

public class User {
    int contact;

    public User() {
    }

    public User(int contact) {
        this.contact = contact;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }
}

